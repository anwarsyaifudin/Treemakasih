<?php
    session_start();
    if(!isset($_SESSION['id12081587_login_db'])) {
        include("loginindex.php");
    }
    else {
    ?>
    <!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Treemakasih - Home</title>
	<link rel="icon" href="img/favicon.png" type="image/png">
  <link rel="stylesheet" href="vendors/bootstrap/bootstrap.min.css">
  <link rel="stylesheet" href="vendors/fontawesome/css/all.min.css">
	<link rel="stylesheet" href="vendors/themify-icons/themify-icons.css">
  <link rel="stylesheet" href="vendors/nice-select/nice-select.css">
  <link rel="stylesheet" href="vendors/owl-carousel/owl.theme.default.min.css">
  <link rel="stylesheet" href="vendors/owl-carousel/owl.carousel.min.css">

  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <!--================ Start Header Menu Area =================-->
	<header class="header_area">
    <div class="main_menu">
      <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container">
          <a class="navbar-brand logo_h" href="index.html"><img src="img/logo.png" alt=""></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <div class="collapse navbar-collapse offset" id="navbarSupportedContent">
            <ul class="nav navbar-nav menu_nav ml-auto mr-auto">
              <li class="nav-item active"><a class="nav-link" href="index.html">Home</a></li>
                          </ul>

            <ul class="nav-shop">
              <li class="nav-item"><button><i class="ti-search"></i></button></li>
              
              <li class="nav-item"><a class="button button-header" href="index.html">Logout</a></li>
            </ul>
          </div>
        </div>
      </nav>
    </div>
  </header>
	<!--================ End Header Menu Area =================-->

  <main class="site-main">
    
    <!--================ Hero banner start =================-->
    <section class="hero-banner">
      <div class="container">
        <div class="row no-gutters align-items-center pt-60px">
          <div class="col-5 d-none d-sm-block">
            <div class="hero-banner__img">
              <img class="img-fluid" src="img/b1.png" alt="">
            </div>
          </div>
          <div class="col-sm-7 col-lg-6 offset-lg-1 pl-4 pl-md-5 pl-lg-0">
            <div class="hero-banner__content">
                  <h4>Shop is fun</h4>
              <h1>Browse Our Premium Flowers</h1>
              <p>Diluncurkan pada tahun 2019, Treemakasih merupakan platform yang dirancang khusus untuk memberikan pengalaman belanja berbagai produk rangkaian bunga secara online, yang tentunya menawarkan akses kemudahan, keamanan, kecepatan, serta kenyamanan kepada pelanggan melalui pembayaran dan dukungan pemenuhan yang kuat. 
                  <br> <br>Sesuai dengan tujuannya, Treemakasih juga memastikan pelanggan mendapatkan kepuasan dengan berbelanja di sini.</p>
              <a class="button button-hero" href="register.html">Daftar Sekarang</a>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--================ Hero banner start =================-->
<!--================ Hero Carousel start =================-->
    <section class="section-margin mt-0">
      <div class="owl-carousel owl-theme hero-carousel">
        <div class="hero-carousel__slide">
          <img src="img/b6.png" alt="" class="img-fluid">
          <a href="#" class="hero-carousel__slideOverlay">
            <h3>Pink Blush</h3>
            <p>Buket Bunga</p>
          </a>
        </div>
        <div class="hero-carousel__slide">
          <img src="img/k2.png" alt="" class="img-fluid">
          <a href="#" class="hero-carousel__slideOverlay">
            <h3>Astoria - Passionate Red</h3>
            <p>Kotak Bunga</p>
          </a>
        </div>
        <div class="hero-carousel__slide">
          <img src="img/p1.png" alt="" class="img-fluid">
          <a href="#" class="hero-carousel__slideOverlay">
            <h3>Consolantibus Jabodetabek</h3>
            <p>Papan Bunga</p>
          </a>
        </div>
      </div>
    </section>
    <!--================ Hero Carousel end =================-->

  
    <!-- ================ offer section start ================= --> 
    <section class="offer" id="parallax-1" data-anchor-target="#parallax-1" data-300-top="background-position: 20px 30px" data-top-bottom="background-position: 0 20px">
      <div class="container">
        <div class="row">
          <div class="col-xl-5">
            <div class="offer__content text-center">
              <h3>Up To 30% Off</h3>
              <h4>January Sale</h4>
              <p>Temukan koleksi buket bunga kami sebagai hadiah untuk orang terkasih kamu.</p>
              <a class="button button--active mt-3 mt-xl-4" href="#">Shop Now</a>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- ================ offer section end ================= --> 

   
    <!-- ================ Best Selling item  carousel ================= --> 
    <section class="section-margin calc-60px">
      <div class="container">
        <div class="section-intro pb-60px">
          <p>Popular Item</p>
          <h2>Best <span class="section-intro__style">Sellers</span></h2>
        </div>
        <div class="owl-carousel owl-theme" id="bestSellerCarousel">
          <div class="card text-center card-product">
            <div class="card-product__img">
                <a href="single-product.html"> <img class="img-fluid" src="img/b5.png"  alt=""> </a>
              <ul class="card-product__imgOverlay">
                <li><button><i class="ti-search"></i></button></li>
                <li><button> <a href="single-product.html"><i class="ti-shopping-cart"></i> </a></button></li>
                <li><button><i class="ti-heart"></i></button></li>
              </ul>
            </div>
            <div class="card-body">
              <p>Buket Bunga</p>
              <h4 class="card-product__title"><a href="single-product.html">Credence Love</a></h4>
              <p class="card-product__price">Rp 450.00</p>
            </div>
          </div>

          <div class="card text-center card-product">
            <div class="card-product__img">
                <a href="single-product.html"> <img class="img-fluid" src="img/b2.png" alt=""> </a>
              <ul class="card-product__imgOverlay">
                <li><button><i class="ti-search"></i></button></li>
                <li><button><a href="single-product.html"><i class="ti-shopping-cart"></i></a></button></li>
                <li><button><i class="ti-heart"></i></button></li>
              </ul>
            </div>
            <div class="card-body">
              <p>Buket Bunga</p>
              <h4 class="card-product__title"><a href="single-product.html">Pink Blush</a></h4>
              <p class="card-product__price">Rp 390.00</p>
            </div>
          </div>

          <div class="card text-center card-product">
            <div class="card-product__img">
                <a href="single-product.html"> <img class="img-fluid" src="img/k5.png" alt=""> </a>
              <ul class="card-product__imgOverlay">
                <li><button><i class="ti-search"></i></button></li>
                <li> <button> <a href="single-product.html"><i class="ti-shopping-cart"></i></a></button></li>
                <li><button><i class="ti-heart"></i></button></li>
              </ul>
            </div>
            <div class="card-body">
              <p>Kotak Bunga</p>
              <h4 class="card-product__title"><a href="single-product.html">Sweet Embrace</a></h4>
              <p class="card-product__price">Rp 520.00</p>
            </div>
          </div>

          <div class="card text-center card-product">
            <div class="card-product__img">
                <a href="single-product.html"> <img class="img-fluid" src="img/k6.png" alt=""> </a>
              <ul class="card-product__imgOverlay">
                <li><button><i class="ti-search"></i></button></li>
                <li><button> <a href="single-product.html"><i class="ti-shopping-cart"></i></a></button></li>
                <li><button><i class="ti-heart"></i></button></li>
              </ul>
            </div>
            <div class="card-body">
              <p>Kotak Bunga</p>
              <h4 class="card-product__title"><a href="single-product.html">Sunflower Mosters</a></h4>
              <p class="card-product__price">RP 550.00</p>
            </div>
          </div>

          <div class="card text-center card-product">
            <div class="card-product__img">
                <a href="single-product.html"> <img class="img-fluid" src="img/b5.png" alt=""> </a>
              <ul class="card-product__imgOverlay">
                <li><button><i class="ti-search"></i></button></li>
                <li><button> <a href="single-product.html"><i class="ti-shopping-cart"></i></a></button></li>
                <li><button><i class="ti-heart"></i></button></li>
              </ul>
            </div>
            <div class="card-body">
              <p>Buket Bunga</p>
              <h4 class="card-product__title"><a href="single-product.html">Credence Love</a></h4>
              <p class="card-product__price">Rp 450.00</p>
            </div>
          </div>

          <div class="card text-center card-product">
            <div class="card-product__img">
                <a href="single-product.html"><img class="img-fluid" src="img/b2.png" alt=""></a>
              <ul class="card-product__imgOverlay">
                <li><button><i class="ti-search"></i></button></li>
                <li><button><a href="single-product.html"><i class="ti-shopping-cart"></i></a></button></li>
                <li><button><i class="ti-heart"></i></button></li>
              </ul>
            </div>
            <div class="card-body">
              <p>Buket Bunga</p>
              <h4 class="card-product__title"><a href="single-product.html">Pink Blush</a></h4>
              <p class="card-product__price">Rp 390.00</p>
            </div>
          </div>

          <div class="card text-center card-product">
            <div class="card-product__img">
                <a href="single-product.html"><img class="img-fluid" src="img/k5.png" alt=""></a>
              <ul class="card-product__imgOverlay">
                <li><button><i class="ti-search"></i></button></li>
                <li><button><a href="single-product.html"><i class="ti-shopping-cart"></i></a></button></li>
                <li><button><i class="ti-heart"></i></button></li>
              </ul>
            </div>
            <div class="card-body">
              <p>Kotak Bunga</p>
              <h4 class="card-product__title"><a href="single-product.html">Sweet Embrace</a></h4>
              <p class="card-product__price">Rp 520.00</p>
            </div>
          </div>

          <div class="card text-center card-product">
            <div class="card-product__img">
                <a href="single-product.html"> <img class="img-fluid" src="img/k6.png" alt=""> </a>
              <ul class="card-product__imgOverlay">
                <li><button><i class="ti-search"></i></button></li>
                <li><button><a href="single-product.html"><i class="ti-shopping-cart"></i></a></button></li>
                <li><button><i class="ti-heart"></i></button></li>
              </ul>
            </div>
            <div class="card-body">
              <p>Kotak Bunga</p>
              <h4 class="card-product__title"><a href="single-product.html">Sunflower Mosters</a></h4>
              <p class="card-product__price">RP 550.00</p>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- ================ Best Selling item  carousel end ================= --> 

    <!-- ================ Blog section start ================= -->  
    <section class="blog">
      <div class="container">
        <div class="section-intro pb-60px">
          <p>Popular Item</p>
          <h2>KOLEKSI<span class="section-intro__style"> TERBARU</span></h2>
        </div>

        <div class="row">
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-0">
            <div class="card card-blog">
              <div class="card-blog__img">
                <img class="card-img rounded-0" src="img/p1.png" height="300" alt="">
              </div>
              <div class="card-body">
                <ul class="card-blog__info">
                  <li><a href="#">100 Terjual</a></li>
                  <li><a href="#"><i class="ti-comments-smiley"></i> 90 Ulasan </a></li>
                </ul>
                <h3 class="card-blog__title"><a href="single-blog.html">Rp 435.000</a></h3>
                <h4 class="card-blog__title"><a href="single-blog.html">Consolantibus Jabodetabek</a></h4>
                <p>Papan Bunga Untuk Ucapan Duka Cita, Desain Terbaik dengan Rangkaian Bunga Fresh dan Suyok, Terbuat dari Styrofoam dan Busa ...</p>
                <a class="card-blog__link" href="#">Order Now <i class="ti-arrow-right"></i></a>
              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-4 mb-4 mb-lg-0">
            <div class="card card-blog">
              <div class="card-blog__img">
                  <img class="card-img rounded-0" src="img/k3.png" height="300" alt="">
              </div>
              <div class="card-body">
                <ul class="card-blog__info">
                  <li><a href="#">87 Terjual</a></li>
                  <li><a href="#"><i class="ti-comments-smiley"></i> 8 Ulasan</a></li>
                </ul>
                <h3 class="card-blog__title"><a href="single-blog.html">Rp 525.000</a></h3>
                <h4 class="card-blog__title"><a href="single-blog.html">Astoria - Passionate Red</a></h4>
                <p>Limited Edition, Mawar Super Premium Warna Passionate Red, Diawetkan dengan Proses Alami, Bertahan Hingga 3 Tahun ...</p>
                <a class="card-blog__link" href="#">Order Now <i class="ti-arrow-right"></i></a>
              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-4 mb-4 mb-lg-0">
            <div class="card card-blog">
              <div class="card-blog__img">
                  <img class="card-img rounded-0" src="img/b6.png" height="300" alt="">
              </div>
              <div class="card-body">
                <ul class="card-blog__info">
                  <li><a href="#">150 Terjual</a></li>
                  <li><a href="#"><i class="ti-comments-smiley"></i> 132 Ulasan</a></li>
                </ul>
                <h3 class="card-blog__title"><a href="single-blog.html">Rp 415.000</a></h3>
                <h4 class="card-blog__title"><a href="single-blog.html">Majestic Roses with Baby Breath Bouquet</a></h4>
                <p>20 Roses, Decorated with Baby Breath and Caspia Flowers, Wrapped in Pink Wrapping Paper ....</p>
                <a class="card-blog__link" href="#">Order Now<i class="ti-arrow-right"></i></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- ================ Blog section end ================= -->  

    <!-- ================ Subscribe section start ================= --> 
    <section class="subscribe-position">
      <div class="container">
        <div class="subscribe text-center">
          <h3 class="subscribe__title">Get Update Flowers</h3>
          <p>Book Your Dream Flowers Now !</p>
          <div id="mc_embed_signup">
            <form target="_blank" action="https://spondonit.us12.list-manage.com/subscribe/post?u=1462626880ade1ac87bd9c93a&amp;id=92a4423d01" method="get" class="subscribe-form form-inline mt-5 pt-1">
              <div class="form-group ml-sm-auto">
                <input class="form-control mb-1" type="email" name="EMAIL" placeholder="Masukan email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Your Email Address '" >
                <div class="info"></div>
              </div>
              <button class="button button-subscribe mr-auto mb-1" type="submit">Daftar Sekarang</button>
              <div style="position: absolute; left: -5000px;">
                <input name="b_36c4fd991d266f23781ded980_aefe40901a" tabindex="-1" value="" type="text">
              </div>

            </form>
          </div>
          
        </div>
      </div>
    </section>
    <!-- ================ Subscribe section end ================= --> 

    
    

  </main>


  <!--================ Start footer Area  =================-->  
  <footer class="footer">
    <div class="footer-area">
      <div class="container">
        <div class="row section_gap">
          <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="single-footer-widget tp_widgets">
              <h4 class="footer_title large_title"> Vision & Mission
              <h5 class="footer_title">  Vision </h5>
              <p> Menjadi penyedia sarana transaksi online pertama dan terpercaya bagi pelaku bisnis florist.</p>
              <br>
              <h5 class="footer_title"> Mission </h5>
              <p>
                <li> Menggunakan teknologi web dan internet secara tepat </li>
                <li> Menyediakan produk dan layanan terbaik kepada pelanggan </li>
                <li> Menjaga hubungan yang baik dengan mitra kami </li>
              </p>
            </div>
          </div>
          <div class="offset-lg-1 col-lg-2 col-md-6 col-sm-6">
            <div class="single-footer-widget tp_widgets">
              <h4 class="footer_title">Quick Links</h4>
              <ul class="list">
                <li><a href="#">Home</a></li>
                <li><a href="#">Shop</a></li>
                <li><a href="#">Contact</a></li>
                <li><a href="#">Register</a></li>
                <li><a href="#">Login</a></li>
              </ul>
            </div>
          </div>
          <div class="col-lg-2 col-md-6 col-sm-6">
            <div class="single-footer-widget instafeed">
              <h4 class="footer_title">Gallery</h4>
              <ul class="list instafeed d-flex flex-wrap">
                <li><img src="img/p2.png" width="75" alt=""></li>
                <li><img src="img/k3.png" width="75" alt=""></li>
                <li><img src="img/b2.png" width="75" alt=""></li>
                <li><img src="img/b5.png" width="71" alt=""></li>
                <li><img src="img/k6.png" width="75"alt=""></li>
                <li><img src="img/k5.png" width="71" alt=""></li>
              </ul>
            </div>
          </div>
          <div class="offset-lg-1 col-lg-3 col-md-6 col-sm-6">
            <div class="single-footer-widget tp_widgets">
              <h4 class="footer_title">Contact Us</h4>
              <div class="ml-40">
                <p class="sm-head">
                  <span class="fa fa-location-arrow"></span>
                  Head Office
                </p>
                <p>Universitas Negeri Jakarta <br>
                  Jl. Rawamangun Muka, RT.11/RW.14, Rawamangun, Kec. Pulo Gadung, Kota Jakarta Timur, Daerah Khusus Ibukota Jakarta 13220
                </p>

                <p class="sm-head">
                  <span class="fa fa-phone"></span>
                  Phone
                </p>
                <p>+6289529564985</p>
  
                <p class="sm-head">
                  <span class="fa fa-envelope"></span>
                  Email
                </p>
                <p>treemakasihofficial@gmail.com</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="footer-bottom">
      <div class="container">
        <div class="row d-flex">
          <p class="col-lg-12 footer-text text-center">
            <!-- Copyright Section -->
            Copyright &copy;<script>document.write(new Date().getFullYear());</script>  <i class="fa fa-heart" aria-hidden="true"></i> by Smatech Development
          </p>
        </div>
      </div>
    </div>
  </footer>
  <!--================ End footer Area  =================-->




  <script src="vendors/jquery/jquery-3.2.1.min.js"></script>
  <script src="vendors/bootstrap/bootstrap.bundle.min.js"></script>
  <script src="vendors/skrollr.min.js"></script>
  <script src="vendors/owl-carousel/owl.carousel.min.js"></script>
  <script src="vendors/nice-select/jquery.nice-select.min.js"></script>
  <script src="vendors/jquery.ajaxchimp.min.js"></script>
  <script src="vendors/mail-script.js"></script>
  <script src="js/main.js"></script>
</body>
</html>
    <?php
    }
?>